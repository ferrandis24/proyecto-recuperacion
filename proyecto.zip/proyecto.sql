-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.11-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando datos para la tabla proyacto.contacto: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `contacto` DISABLE KEYS */;
INSERT INTO `contacto` (`id`, `nombre`, `email`, `website`, `asunto`, `mensaje`) VALUES
	(1, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'adasdasdasdasd'),
	(2, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'adasdasdasdasd'),
	(3, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'tertwert'),
	(4, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'tertwert'),
	(5, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'dserrtzwsertewsrtwe'),
	(6, 'Pedro', 'pedrosanchez@soycanelo.si', 'Hola que tal', 'Soy un canelo', 'dserrtzwsertewsrtwe');
/*!40000 ALTER TABLE `contacto` ENABLE KEYS */;

-- Volcando datos para la tabla proyacto.migration_versions: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
	('20200418104731', '2020-04-18 10:47:37'),
	('20200418105145', '2020-04-18 10:51:50'),
	('20200418110340', '2020-04-18 11:03:47'),
	('20200419145955', '2020-04-19 15:00:12'),
	('20200528171637', '2020-05-28 17:16:54');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;

-- Volcando datos para la tabla proyacto.productos: ~19 rows (aproximadamente)
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` (`id`, `nombre`, `marca`, `precio`, `ruedas`, `tipo`, `imagen`, `descripcion`) VALUES
	(1, 'Igloo legend 6', 'Iberica', 17, 'no', 'Nevera', 'IGLOO LEGEND 6 AZUL.jpg', '\nMayor retención del frío gracias a la cámara de aislante térmico Ultratherm:registered: exclusivo de Igloo.\nSoportes para bebidas al invertir la tapa.El aislante térmico de todas las neveras Igloo es de Poliuretano Inyectado de Alta Densidad que las hace'),
	(2, 'Igloo playmate elite azul', 'Iberica', 33, 'no', 'Nevera', 'IGLOO PLAYMATE ELITE AZUL.jpg', 'El tono del Azul puede variar'),
	(3, 'Igloo Playmate elite roja', 'Iberica', 41, 'no', 'Nevera', '00012424-H1.jpg', 'El diseño preferido por los consumidores.El aislante térmico de todas las neveras Igloo es de Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante. La diferencia con las neveras de bajo precio es que '),
	(4, 'igloo playmate mini', 'Iberica', 22, 'no', 'Nevera', 'IGLOO PLAYMATE MINI.jpg', 'Llevamos más de 45 años trabajando día a día, con dedicación y esfuerzo, lo que nos ha dotado de una experiencia y conocimientos que trasladamos a cada servicio que ofrecemos.Llevamos más de 45 años trabajando día a día, con dedicación y esfuerzo, lo que '),
	(5, 'IGLOO PLAYMATE PAL', 'Iberica', 26, 'no', 'Nevera', 'IGLOO PLAYMATE PAL ROJA.jpg', 'El diseño preferido por los consumidores.'),
	(6, 'Igloo glide pro 10', 'Iberica', 165, 'Si', 'Nevera', '00034378.png', 'Asa telescopica muy comoda para transportar por la largura de esta. El aislante térmico de todas las neveras Igloo es Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante. La diferencia con las nevera'),
	(8, 'Igloo maxcold latitude 90 roller', 'Iberica', 161, 'Si', 'Nevera', '00044679-F.jpg', 'Cuidamos a nuestros clientes. Con nuestro servicio post-venta le ayudaremos y atenderemos de manera individual en todo lo que necesites, siempre con un tono amable y comprensivo, tal y como somos. Y todo ello con los que posiblemente sean, los precios más'),
	(9, 'Igloo marine ultra 72', 'Iberica', 196, 'no', 'Nevera', 'IGLOO MARINE ULTRA 72.jpg', 'Mayor retención del frío gracias a la cámara de aislante térmico Ultratherm® exclusivo de IglooEl aislante térmico de todas las neveras Igloo es de Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante'),
	(10, 'Igloo maxcold 165', 'Iberica', 232, 'no', 'Nevera', 'pic.png', 'Cámara de aislante térmico especial MaxCold en cuerpo y tapa.El aislante térmico de todas las neveras Igloo es Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante. La diferencia con las neveras de ba'),
	(11, 'IGLOO TRANSFORMER 60 ROLLER', 'Iberica', 232, 'si', 'Nevera', 'pic.png', 'Tamaño ideal para comida y bebidas entre amigos, familia, equipos deportivos y eventos. El aislante térmico de todas las neveras Igloo es de Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante. La di'),
	(12, 'IGLOO POLAR 120', 'Iberica', 232, 'no', 'Nevera', 'pic.png', '.Mayor retención del frío gracias a la cámara de aislante térmico Ultratherm® exclusivo de Igloo.'),
	(13, 'IGLOO QUICK&COOL 100', 'Iberica', 153, 'no', 'Nevera', 'IGLOO QUICK & COOL 100.jpg', 'Mayor retención del frío gracias a la cámara de aislante térmico Ultratherm® exclusivo de Igloo.'),
	(14, 'Igloo marine ultra 74', 'Iberica', 300, 'no', 'Nevera', 'pic.png', 'Mayor retención del frío gracias a la cámara de aislante térmico Ultratherm® exclusivo de IglooEl aislante térmico de todas las neveras Igloo es de Poliuretano Inyectado de Alta Densidad que las hace muy fuertes, resistentes y de gran poder termo aislante'),
	(15, 'IGLOO MARINE ULTRA 73', 'Iberica', 196, 'no', 'Nevera', 'pic.png', 'Mayor retención del frío gracias a la cámara de aislante térmico Ultratherm® exclusivo de Igloo.'),
	(16, 'IGLOO GLIDE PRO 110', 'Iberica', 212, 'si', 'Nevera', 'pic.png', 'Desarrollada por expertos, su asa telescópica mantiene la mayor parte del peso lejos del cuerpo del usuario. Muy fácil de trasportar, ya sea tirando o empujando. El aislante térmico de todas las neveras Igloo es Poliuretano Inyectado de Alta Densidad que '),
	(17, 'BOTELLA INFANTIL CYCLONE 473 ml', 'Iberica', 7, 'no', 'Botella', 'BOTELLA-INFANTIL-CYCLONE-473-ml-azul.png', 'Fabricada con resina PCGT. Cuerpo y base con EVA antideslizante Aspiracion vertical . Boquilla protegida contra la suciedad. Comoda asa de transporte No gotea. Libre de BPA ( BPA FREE) Colores variados'),
	(18, 'BOTELLA INFUSION 828 ml', 'Iberica', 6, 'no', 'Botella', 'BOTELLA-INFUSION-828-ml-REF-B08346IS-AZUL.png', 'Fabricada con resina PP. Aspiracion vertical con pajita curvada . No gotea. Libre de BPA ( BPA FREE)'),
	(19, 'VASO INFANTIL DINO 532 ml', 'Iberica', 5, 'no', 'Botella', 'VASO-INFANTIL-DINO-532-ml.png', 'Fabricada con resina PP. Aspiracion vertical con pajita curvada . No gotea. Libre de BPA ( BPA FREE)');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

-- Volcando datos para la tabla proyacto.usuario: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`id`, `nombre`, `contrasena`) VALUES
	(1, 'pepe', 'notas');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
