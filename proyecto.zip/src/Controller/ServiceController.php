<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Entity\{Productos, Contacto, Usuario};
use App\Repository\ProductosRepository;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\ContactaType;
class ServiceController extends AbstractController
{
    /**
    * @Route("/", name="index")
    */
    // Con esta función hago que haga render de la página principal
    public function index(SessionInterface $session)
    {
        $login = $session->get('username');
        return $this->render('service/index.html.twig',[
            "user" => $login


        ]);
    }
    /**
    * @Route("/servicios", name="servicios")
    */
    // Con esta función hago que haga render de la página de servicios
    public function servicios(SessionInterface $session)
    {
        $login = $session->get('username');
       return $this->render('service/servicios.html.twig');
    }
    /**
    * @Route("/productos/{currentPage?1}", name="productos")
    */
    // Con esta función hago que haga render de la página de productos y cuando la variable page cambie a 2 haga render de ésta,
    // también hace que si la url cambia a cualquier otro numero o nombre me redirija a la primera página de productos
    public function productos($currentPage, ProductosRepository $ProductosRepository, SessionInterface $session)
    {
        $login = $session->get('username');
        return $this->render('service/productos.html.twig',[
            'currentPage' => $currentPage,
            'data' => $proyecto=$this->getDoctrine()->getRepository(productos::Class)->findall(),
        ]);
    }
  /**
    * @Route("/detalle/{detalle}", name="detalle")
    */
    public function detalle($detalle, SessionInterface $session)
    {
        $login = $session->get('username');
        return $this->render('service/detalle.html.twig',[
            'detalle' => $detalle,
            'data' => $proyecto=$this->getDoctrine()->getRepository(productos::Class)->findall(),
        ]);
    }
    /**
    * @Route("/nosotros", name="nosotros")
    */
    // Con esta función hago que haga render de la página de nosotros
    public function nosotros(SessionInterface $session)
    {
        $login = $session->get('username');
        return $this->render('service/nosotros.html.twig');
    }
    /**
    * @Route("/contacto", name="contacto")
    */
    // Con esta función hago que haga render de la página de contacto
    public function contacto(Request $request, SessionInterface $session)
    {
        $login = $session->get('username');
        $contactoBBDD=$this->getDoctrine()->getRepository(Contacto::Class)->findAll();
        $contacto=new Contacto();
        $form=$this->CreateForm(ContactaType::Class, $contacto);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $entityManager=$this->getDoctrine()->getManager();
            $entityManager->persist($contacto);
            $entityManager->flush();}
        return $this->render('service/contacto.html.twig', [
            'form' => $form->CreateView(),
            'contactobbdd' => $contactoBBDD,
        ]);

    }
    /**
    * @Route("/contacto/preview", name="contacto2")
    */
    // Con esta función hago que haga render de la página de contacto2 y pida los
    public function send(Request $request)
    {
        $nombre = $request->request->get('name');
        $email = $request->request->get('email');
        $website = $request->request->get('website');
        $asunto = $request->request->get('subject');
        $mensaje = $request->request->get('message');
        if ($website == 0){
            $website = "Campo vacío";
        }
        if ($asunto == 0){
            $asunto = "Campo vacío";
        }
        return $this->render('service/contacto2.html.twig', [
            'nombre' => $nombre,
            'email' => $email,
            'website' => $website,
            'asunto' => $asunto,
            'mensaje' => $mensaje,
        ]);
    }
    /**
    * @Route("/login", name="login")
    */
    // Aquí se ve si el usuario esta conectado o no
    public function login(SessionInterface $session, Request $request)
    {
        $nombreUser = $request->request->get('user');
        $password = $request->request->get('pasword');
        $login = $session->get('username');
        $mensajeError="";

        if ($nombreUser) {
            $userBBDD=$this->getDoctrine()
            ->getRepository(Usuario::Class)
            ->findOneBy(
                ['nombre' => $nombreUser]);
                var_dump("hola");


            if ($userBBDD) {
                if ($nombreUser == $userBBDD->getNombre() && $password ==  $userBBDD->getContrasena()) {
                    var_dump("Hola".$userBBDD->getNombre()."Estas jamao");
                    $session->set('username', $userBBDD->getNombre());
                    return $this->render('service/index.html.twig');
            }
            else {
                $mensajeError= "El usuario o la contrseña no existe"; 
                var_dump("hola");
            } 
            }
            else {
                $mensajeError= "El usuario o la contrseña no existe"; 
                var_dump("hola");
            } }

        


        if ($login != "") {
            $mensaje = "Usuario ".$login." conectado.";
        } else {
            $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
        }
        return $this->render('service/login.html.twig', [
            'mensajesesion' => $mensaje,
            'login' => $login,
            "user" => $nombreUser,
            "mensaje" => $mensaje,
            "mensajeError" => $mensajeError
        ]);
    }
    // /**
    // * @Route("/loggedin", name="logging")
    // */
    // // Aquí se creara la sesión
    // public function logging(Request $request, SessionInterface $session)
    // {
    //     $login = $request->request->get('user'); 
    //     if ($login != "") {
    //         $session->set('username', $login);
    //         $mensaje = "Usuario ".$login." conectado.";
    //     } else {
    //         $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
    //     }
    //     return $this->render('service/index.html.twig', [
    //         'mensajesesion' => $mensaje,
    //         'login' => $login
    //     ]);
    // }
    /**
    * @Route("/logout", name="logout")
    */
    // Aqui el usuario se desloguea
    public function logout(SessionInterface $session)
    {
        $session->clear();
        $session->invalidate();
        return $this->redirectToRoute('index');
    }
}
